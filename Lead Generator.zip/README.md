# ChromeExt-LeadGenerator
 This is the 3rd challenge from freeCodeCamp's JS tutorial on youtube.
